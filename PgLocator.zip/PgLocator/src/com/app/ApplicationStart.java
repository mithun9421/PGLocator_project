package com.app;

import java.io.*;
import java.util.*;

import com.contractor.ContractorDao;
import com.contractor.UpdateHostelFeedback;
import com.hostel.HostelBean;
import com.hostel.HostelDao;
import com.owner.HostelDeletion;
import com.owner.HostelRegistration;
import com.owner.OwnerDao;
import com.tenant.TenantDao;


public class ApplicationStart {

	public static void main(String[] args) throws IOException, Exception 
	{
			//Hello Run me through
			Scanner scn = new Scanner(System.in);
			char contornot ;
			do
			{
			System.out.println("Please select an option to continue:" + "\n" 
			+"1.Get list of hostels" + "\n" 
			+ "2.Contractor Feedback" + "\n" 
			+ "3.Register for new hostel" +"\n" 
			+ "4.Remove existing hostel" + "\n" 
			+ "5.Book for hostel" + "\n"
			+ "6.Vacate from Hostel" );
			int choice = scn.nextInt();
			
			switch (choice) {
			case 1:	HostelDao hostelDao = new HostelDao();
				    hostelDao.getHostels();
				    break;
			
			case 2: System.out.println("Contractor Username:");
					String uname = scn.next().toUpperCase();
					System.out.println("Contractor Password");
					String pwd = scn.next().toUpperCase();
					boolean isValid = ContractorDao.isValid(uname,pwd);
					if(isValid == true)
							UpdateHostelFeedback.updateFeedback();
					else
					{
						System.out.println("Wrong Password...try again");
					}
					break;
					
			case 3: System.out.println("Owner Username:");
					uname = scn.next().toUpperCase();
					System.out.println("Owner Password");
					pwd = scn.next().toUpperCase();
					if(OwnerDao.isValid(uname, pwd, "OWNER"))
						HostelRegistration.registerHostel(uname);
					else
					{
						System.out.println("Wrong password COmbination...Try again");
					}
					break;
					
			case 4: System.out.println("Owner Username:");
					uname = scn.next().toUpperCase();
					System.out.println("Owner Password");
					pwd = scn.next().toUpperCase();
					if(OwnerDao.isValid(uname, pwd, "OWNER") == true){
						System.out.println("Enter the Hostel ID");
						int hostelID = scn.nextInt();
						HostelDeletion.deleteHostel(hostelID,uname);
					}
					else
					{
						System.out.println("Wrong password Combination...Try again");
					}
					break;
					
			case 5: System.out.println("Booking For Hostel");
					System.out.println("Tenant Username:");
					uname = scn.next().toUpperCase();
					System.out.println("Tenant Password");
					pwd = scn.next().toUpperCase();
					if(OwnerDao.isValid(uname, pwd, "TEN") == true){
							System.out.println("Enter the hostel ID to be booked:");
							int bookId = scn.nextInt();
							TenantDao.bookRoom(bookId,uname);
					}
					else
					{
						System.out.println("Wrong password Combination...Try again");
					}
			break;
					
			default: System.out.println("Please enter a valid choice to continue(yes/no)");
			}
			
			System.out.println("Do you wish to continue:");
			contornot = Character.toLowerCase(scn.next().charAt(0));
			}while(contornot == 'y');

		}
}
