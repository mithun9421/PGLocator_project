package com.contractor;

public class ContractorBean {
	
	private String contractorId;
	private String contractorPwd;
	
	
	public String getContractorId() {
		return contractorId;
	}
	public void setContractorId(String contractorId) {
		this.contractorId = contractorId;
	}
	public String getContractorPwd() {
		return contractorPwd;
	}
	public void setContractorPwd(String contractorPwd) {
		this.contractorPwd = contractorPwd;
	}
	
	
	
}
