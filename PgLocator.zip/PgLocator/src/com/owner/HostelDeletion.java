package com.owner;

import java.io.*;
import java.sql.*;

import com.hostel.ConnectionManager;
import com.sun.javafx.runtime.SystemProperties;

public class HostelDeletion {
	
	public static void deleteHostel(int id,String Username)
	{
		BufferedReader br = new BufferedReader (new InputStreamReader (System.in));
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = con.prepareStatement("SELECT OWNER_ID FROM T_XBBNHGK_ACCOMODATION_DETAIL WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			
			String retrievedOwnerID = "";
			
			while(rs.next())
				retrievedOwnerID = rs.getString(1);
			System.out.println(retrievedOwnerID);
			
			if(Username.equalsIgnoreCase(retrievedOwnerID) == true)
			{
			System.out.println("Inside the if");
			//Deleting from foreign table
			pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_ROOM_FACILITIES WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			pstmt.executeUpdate();
			//Deleting from parent table
			pstmt = con.prepareStatement("DELETE FROM T_XBBNHGK_ACCOMODATION_DETAIL WHERE ACC_ID = ?");
			pstmt.setInt(1, id);
			pstmt.executeUpdate();			
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
