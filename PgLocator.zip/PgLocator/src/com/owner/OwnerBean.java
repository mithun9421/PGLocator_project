package com.owner;

public class OwnerBean {
	
	private String OwnerID;
	private String OwnerName;
	private String OwnerPhoneNumber;
	
	
	public String getOwnerID() {
		return OwnerID;
	}
	public void setOwnerID(String ownerID) {
		OwnerID = ownerID;
	}
	public String getOwnerName() {
		return OwnerName;
	}
	public void setOwnerName(String ownerName) {
		OwnerName = ownerName;
	}
	public String getOwnerPhoneNumber() {
		return OwnerPhoneNumber;
	}
	public void setOwnerPhoneNumber(String ownerPhoneNumber) {
		OwnerPhoneNumber = ownerPhoneNumber;
	}
	
	

}
