package com.tenant;

import java.sql.*;

import com.hostel.ConnectionManager;

public class TenantDao {
	
	
	

	public static void bookRoom(int bookId,String tenantId) {
		// TODO Auto-generated method stub
		try{
			ResultSet rs = null;
			Connection con = ConnectionManager.getConnection();
			PreparedStatement pstmt = con.prepareStatement("SELECT TENANT_HAS_HOME FROM T_XBBNHGK_TENANT_DETAILS WHERE TENANT_ID = ?");
			pstmt.setString(1, tenantId);
			rs = pstmt.executeQuery();
			String tenantHasHome = "";
			while(rs.next())
			{
				tenantHasHome = rs.getString(1);
			}
			if(tenantHasHome.equals("NO"))
			{
				pstmt = con.prepareStatement("SELECT ACC_NO_OF_FREE_COT,ACC_MAX_CAPACITY FROM T_XBBNHGK_ROOM_FACILITIES WHERE ACC_ID = ?");
				pstmt.setInt(1, bookId);
				rs = pstmt.executeQuery();
				int noOfFreeCots = 0;
				int max_capacity = 0;
				
				while(rs.next())
				{
					noOfFreeCots = rs.getInt(1);
					max_capacity = rs.getInt(2);
				}
				
				String RoomVacant = "";
				if(max_capacity - noOfFreeCots > 0)
				{
					RoomVacant = "YES";
				}
				else
				{
					RoomVacant = "NO";
				}
				noOfFreeCots = noOfFreeCots - 1;
				
				pstmt = con.prepareStatement("UPDATE T_XBBNHGK_ROOM_FACILITIES SET ACC_HAS_ROOM_VACANT = ?, ACC_NO_OF_FREE_COT = ? WHERE ACC_ID = ?");
				pstmt.setString(1, RoomVacant);
				pstmt.setInt(2, noOfFreeCots);
				pstmt.setInt(3, bookId);
				pstmt.executeUpdate();
				
				pstmt = con.prepareStatement("UPDATE T_XBBNHGK_TENANT_DETAILS SET TENANT_HAS_HOME = ? WHERE TENANT_ID = ?");
				pstmt.setString(1, "YES");
				pstmt.setString(2, tenantId);
				pstmt.executeUpdate();
				}
			else
			{
				System.out.println("You already have a home, Dude!!!");
			}
			}
			catch(SQLException e)
			{
				e.printStackTrace();
			}
		
		
	}
	
	
}