function validateButton() {

        var x = document.getElementById("uname").value;

        var y = document.getElementById("psw").value;

        if (x == null || x.length == 0 || x == undefined) {

                alert("Please Enter Name");

                return false;

        }

        if (y == null || y.length == 0 || y == undefined) {

                alert("Please Enter Email");

                return false;

        }

}

