import java.io.*;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.contractor.*;
public class TenantValidation extends HttpServlet{
	
	public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");  
	    try {
			PrintWriter out = response.getWriter();
		} catch (IOException e) {
			
			e.printStackTrace();
		}  
	    
	    String n=request.getParameter("username");  
	    String p=request.getParameter("password");  
	    ServletConfig config=getServletConfig();
	    boolean isValid = false;
	    try {
			isValid = ContractorDao.isValid(n, p);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    if(isValid == true)
	    {
	    	RequestDispatcher rd = request.getRequestDispatcher("tenant1.html");
	    	rd.forward(request, response); 
	    }
	    else
	    {
	    	RequestDispatcher rd = request.getRequestDispatcher("index.html");
	    	rd.forward(request, response); 
	    }
	    
	    
	}

}
