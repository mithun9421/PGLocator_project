package com.admin;

import java.io.*;
import java.sql.*;

import com.hostel.ConnectionManager;

public class AdminDao {

	public static void start() {
		BufferedReader br = new BufferedReader (new InputStreamReader(System.in));
		int choice = 0;
		System.out.println("1) Display Login Credentials \n "
				+ "2) Display Tenant Table "
				+ "3) Display Login Table \n "
				+ "4) Display Homes and Tenants living in it \n"
				+ "5) Display Owner Details");
		try {
			choice = Integer.parseInt(br.readLine());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		switch (choice) {
		case 1:		Connection con = ConnectionManager.getConnection();
					try {
							Statement stmt = con.createStatement();
							ResultSet rs = stmt.executeQuery("select * from  T_XBBNHGK_CREDENTIALS");
							System.out.println("USERID" +  "   "  + "PASS" + "   " + "LOGIN TYPE");
							while(rs.next())
							{
								System.out.println(rs.getString(1) + "   " + rs.getString(2) + "    " + rs.getString(3));
							}
							
						} 
					catch (SQLException e) {
						e.printStackTrace();
					}
					break;
		
		case 2:	    con = ConnectionManager.getConnection();
					try
					{
						Statement stmt = con.createStatement();
						ResultSet rs = stmt.executeQuery("select * from T_XBBNHGK_TENANT_DETAILS");
						System.out.println("TENANTID" + "  " + "ACCID" + "  " + "TEN NAME" + "        " + "PHONENO" +  "         "  + "MARITAL" + "       " + "ACCLOCATED HOME?");
						while(rs.next())
						{
							System.out.println(rs.getString(1) + "     "  + rs.getString(2) + "    " + rs.getString(3) + "     " + rs.getString(4) + "      " + rs.getString(5) + "      " + rs.getString(6));
						}
					}
					catch(SQLException e){
						e.printStackTrace();
					}
			
			break;

		default:
			break;
		}
		
		
	}
	
	

}
