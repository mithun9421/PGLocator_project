package com.contractor;

import java.sql.*;

import com.hostel.ConnectionManager;

public class ContractorDao {

	public static boolean isValid(String username,String password) throws SQLException
	{
		
		Connection con = ConnectionManager.getConnection();
		PreparedStatement stmt = null;
		
			stmt = con.prepareStatement("select * from T_XBBNHGK_CREDENTIALS where LOGIN_ID = ? AND LOGIN_PWD = ? AND LOGIN_TYPE = ?");
			stmt.setString(1, username);
			stmt.setString(2, password);
			stmt.setString(3, "CONT");
		boolean isValid = false;
		ResultSet rs = null;
		
		rs = stmt.executeQuery();
			
		while(rs.next())
		{
			isValid = true;
		}
		return isValid;
		
	}
	
}
