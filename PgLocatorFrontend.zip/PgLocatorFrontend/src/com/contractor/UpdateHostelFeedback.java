package com.contractor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.hostel.ConnectionManager;

public class UpdateHostelFeedback {
	
	public static void updateFeedback()
	{
	Connection conn = ConnectionManager.getConnection();

	BufferedReader br = new BufferedReader( new InputStreamReader (System.in));
	
	int tempid = 0;
	int temprating = 0;
	try {
		System.out.println("Enter the room ID");
		tempid = Integer.parseInt(br.readLine());

	} catch (NumberFormatException | IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	try {
		System.out.println("Enter the rating to be updated");
		temprating = Integer.parseInt(br.readLine());
	} catch (NumberFormatException | IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	String tempfeedback = "";
	System.out.println("Enter the feedback about the hostel:");
	try {
		tempfeedback = br.readLine();
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	
	PreparedStatement ps = null;
	String updateQuery = "UPDATE T_XBBNHGK_ACCOMODATION_DETAIL SET ACC_RATING = ? , ACC_FEEDBACK = ? WHERE ACC_ID = ?";
	try
	{
		ps = conn.prepareStatement(updateQuery);
		ps.setInt(1, temprating);
		ps.setString(2, tempfeedback);
		ps.setInt(3, tempid);
		ps.executeUpdate();
	}
	
	catch(Exception e)
	{
		e.printStackTrace();
	}	

}
}
