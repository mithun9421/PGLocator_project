package com.hostel;
import java.sql.*;

public class ConnectionManager {
   static Connection con;
   public static Connection getConnection()
   {
      try
      {
    	Class.forName("org.apache.derby.jdbc.ClientDriver");
        try {
				con = DriverManager.getConnection("jdbc:derby://172.24.18.179:1527/pgloc;create=true;user=user;password=pwd");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
      }
      catch(ClassNotFoundException e)
      {
         System.out.println(e);
      }
   return con;
}
}