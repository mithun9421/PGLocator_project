package com.hostel;

import java.io.*;
import java.sql.*;
import java.util.*;

public class GetHostel {
	
	public static List getAllHostels() throws Exception
	{
		Connection con = ConnectionManager.getConnection();
		Statement stmt = con.createStatement();
		List<HostelBean> hostelList = new ArrayList<HostelBean>();
		String searchQuery = "SELECT * FROM T_XBBNHGK_ACCOMODATION_DETAIL NATURAL JOIN T_XBBNHGK_ROOM_FACILITIES";
		ResultSet rs = stmt.executeQuery(searchQuery);
		while(rs.next())
		{
			HostelBean temp = new HostelBean();
			temp.setHostelID(rs.getInt(1));
			temp.setHostelName(rs.getString(2));
			temp.setHostelAddress(rs.getString(3));
			temp.setHostelLocation(rs.getString(4));
			temp.setHostelRating(rs.getInt(5));
			temp.setHostelFeedback(rs.getString(6));
			temp.setRoomHasWifi(rs.getString(8));
			temp.setRoomHasTV(rs.getString(9));
			temp.setRoomHasFood(rs.getString(10));
			temp.setRoomHasFurnished(rs.getString(11));
			temp.setRoomHasAttachedToilet(rs.getString(12));
			temp.setRoomHasSingleOccupancy(rs.getString(13));
			temp.setRoomHasSharedOccupancy(rs.getString(14));
			temp.setRoomHasRefrigerator(rs.getString(15));
			temp.setRoomHasSecurity(rs.getString(16));
			temp.setRoomHasWashingMachine(rs.getString(17));
			temp.setRoomHasCupboard(rs.getString(18));
			temp.setRoomHasVacant(rs.getString(19));
			temp.setRoomNoOfCotsVacant(rs.getInt(20));
			temp.setRoomMaxCapacity(rs.getInt(21));
			hostelList.add(temp);
		}		
		return hostelList;
	}
	
	public static List getSpecHostels() throws Exception
	{
		
		BufferedReader br = new BufferedReader (new InputStreamReader (System.in));
		HostelBean hBean = new HostelBean();
		List<HostelBean> hostelList = new ArrayList<HostelBean>();
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = con.prepareStatement("SELECT * FROM T_XBBNHGK_ACCOMODATION_DETAIL a NATURAL JOIN T_XBBNHGK_ROOM_FACILITIES b where b.ACC_HAS_WIFI = ? AND b.ACC_HAS_TV = ? AND b.ACC_HAS_FOOD = ? AND b.ACC_HAS_FURNISHED = ? AND b.ACC_HAS_ATTACHED_TOILET = ? AND b.ACC_HAS_SINGLE_OCCUPANCY = ? AND b.ACC_HAS_SHARED_OCCUPANCY = ? AND b.ACC_HAS_REFRIGERATOR = ? AND b.ACC_HAS_SECURITY = ? AND b.ACC_HAS_WASHING_MACHINE = ? AND b.ACC_HAS_CUPBOARD = ?");
		System.out.println("Select Facilities:\nWifi\nTV\nFood\nPre-fursnished\nAttached Toilet\nSingle Occupancy\nShared Occupancy\nRefrigerator\nSecurity\nWashing machine\nCupboard");
		
		hBean.setRoomHasWifi(br.readLine());
		hBean.setRoomHasTV(br.readLine());
		hBean.setRoomHasFood(br.readLine());
		hBean.setRoomHasFurnished(br.readLine());
		hBean.setRoomHasAttachedToilet(br.readLine());
		hBean.setRoomHasSingleOccupancy(br.readLine());
		hBean.setRoomHasSharedOccupancy(br.readLine());
		hBean.setRoomHasRefrigerator(br.readLine());
		hBean.setRoomHasSecurity(br.readLine());
		hBean.setRoomHasWashingMachine(br.readLine());
		hBean.setRoomHasCupboard(br.readLine());
		
		pstmt.setString(1, hBean.getRoomHasWifi());
		pstmt.setString(2, hBean.getRoomHasTV());
		pstmt.setString(3, hBean.getRoomHasFood());
		pstmt.setString(4, hBean.getRoomHasFurnished());
		pstmt.setString(5, hBean.getRoomHasAttachedToilet());
		pstmt.setString(6, hBean.getRoomHasSingleOccupancy());
		pstmt.setString(7, hBean.getRoomHasSharedOccupancy());
		pstmt.setString(8, hBean.getRoomHasRefrigerator());
		pstmt.setString(9, hBean.getRoomHasSecurity());
		pstmt.setString(10, hBean.getRoomHasWashingMachine());
		pstmt.setString(11, hBean.getRoomHasCupboard());
		
		
		
		ResultSet rs = pstmt.executeQuery();	
		while(rs.next())
		{
			HostelBean temp = new HostelBean();
			temp.setHostelID(rs.getInt(1));
			temp.setHostelName(rs.getString(2));
			temp.setHostelAddress(rs.getString(3));
			temp.setHostelLocation(rs.getString(4));
			temp.setHostelRating(rs.getInt(5));
			temp.setHostelFeedback(rs.getString(6));
			temp.setRoomHasWifi(rs.getString(8));
			temp.setRoomHasTV(rs.getString(9));
			temp.setRoomHasFood(rs.getString(10));
			temp.setRoomHasFurnished(rs.getString(11));
			temp.setRoomHasAttachedToilet(rs.getString(12));
			temp.setRoomHasSingleOccupancy(rs.getString(13));
			temp.setRoomHasSharedOccupancy(rs.getString(14));
			temp.setRoomHasRefrigerator(rs.getString(15));
			temp.setRoomHasSecurity(rs.getString(16));
			temp.setRoomHasWashingMachine(rs.getString(17));
			temp.setRoomHasCupboard(rs.getString(18));
			temp.setRoomHasVacant(rs.getString(19));
			temp.setRoomNoOfCotsVacant(rs.getInt(20));
			temp.setRoomMaxCapacity(rs.getInt(21));
			hostelList.add(temp);
		}
		return hostelList;
	}

}
