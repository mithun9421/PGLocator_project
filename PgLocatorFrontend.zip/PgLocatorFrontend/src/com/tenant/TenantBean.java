package com.tenant;

public class TenantBean {
	
	//TENANT INFORMATION
		private int user_ID;
		private String user_name;
		private int user_phone_no;
		private String user_marital_status;
		
		
		public int getUser_ID() {
			return user_ID;
		}
		public void setUser_ID(int user_ID) {
			this.user_ID = user_ID;
		}
		public String getUser_name() {
			return user_name;
		}
		public void setUser_name(String user_name) {
			this.user_name = user_name;
		}
		public int getUser_phone_no() {
			return user_phone_no;
		}
		public void setUser_phone_no(int user_phone_no) {
			this.user_phone_no = user_phone_no;
		}
		public String getUser_marital_status() {
			return user_marital_status;
		}
		public void setUser_marital_status(String user_marital_status) {
			this.user_marital_status = user_marital_status;
		}
		
		

}
