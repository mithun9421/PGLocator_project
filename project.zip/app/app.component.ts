import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: `home/agreement.html`,
  styleUrls: ['css/viewagreement.css']
})

export class AppComponent  {

  over(){
    console.log("Mouseover called");
  }
  
    details = [
        {
          "accountnumber":"10987654321",
          "status":"Pending",
          "relationshipmanager":"Michael Ranieri",
          "clientnumber":"Joy Cone Co - Dean Jacobson - Scott Josephson Indemnification Escrow Amount",
          "region":"Pittsburgh",
          "opendate":"03/14/2017",
          "amount":"3000"
        },
          {
          "accountnumber":"1206801",
          "status":"Denied",
          "relationshipmanager":"Pamela Gill",
          "clientnumber":"Joy Cone Co - Dean Jacobson - Scott Josephson Indemnification Escrow Amount",
          "region":"Pittsburgh",
          "opendate":"  09/29/2016 ",
          "amount":"14,276,635.02"
        }
    ];
}
