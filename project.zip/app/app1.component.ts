import { Component } from '@angular/core';


@Component({
  selector: 'my-app1',
  templateUrl: `home/trigger.html`,
  styleUrls: ['css/trigger.css']
})

export class AppComponent1
{
    
}